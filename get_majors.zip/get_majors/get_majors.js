$(document).ready(function() {
	$("#majors").on("click",function() {
		
	});
});